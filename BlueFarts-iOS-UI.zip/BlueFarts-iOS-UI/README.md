# BlueFarts iPhone UI Preview

A standalone UI adaptation of your **LGL 3.2 horizontal-tab Android menu**. Edit it in VS Code on Windows, preview it in a browser, and build the iPhone app with the included macOS cloud workflow.

**This ZIP contains source code, not a compiled IPA.** The workflow creates an unsigned IPA; Sideloadly signs and installs it. Native compilation and installation have not been verified here.

## Start on Windows

1. Extract the whole ZIP.
2. Double-click **`preview-windows.cmd`** to open the menu in your default browser.
3. Open this folder in VS Code. Edit `BlueFartsUI/Web/`, save and refresh the browser.
4. Choose **DEMO PRESET**, then **HIDE**, to inspect the sample ESP scene. Tap the floating icon to reopen the menu.

No Node, Flutter, Java or Android Studio installation is required for the browser preview.

## Included

- Five tabs: ESP / Bullet Track, Player, Adjustable, Skin and Settings.
- Original BlueFarts icon, cyan/black styling and feature labels.
- 18 player switches, 6 adjustable sliders and 23 searchable skin entries.
- Touch/mouse dragging, resizing, minimize, close and reopen.
- Local preferences, icon settings, accent colors and crosshair controls.
- Sample ESP boxes, lines, skeletons, health bars and aim-line visuals.
- A Swift/WebKit app shell targeting iOS 16+.
- A manual GitHub Actions workflow to build an unsigned ARM64 IPA.

Controls change local preview values. ESP uses generated sample targets. The menu runs inside its own app; Android game hooks and cross-app overlays are not ported.

## Edit these files

| File | Purpose |
|---|---|
| `BlueFartsUI/Web/style.css` | Colors, fonts, spacing, buttons and tabs |
| `BlueFartsUI/Web/index.html` | Menu frame and page structure |
| `BlueFartsUI/Web/menu-data.js` | Feature labels, numeric IDs, ranges and defaults |
| `BlueFartsUI/Web/app.js` | Interactions, saved values and sample ESP drawing |
| `BlueFartsUI/App.swift` | iPhone app shell |

Read **[Windows → iPhone](docs/WINDOWS-TO-IPHONE.md)** for build/install steps, **[Port notes](docs/PORT-NOTES.md)** for scope, and **[Validation](docs/VALIDATION.md)** for what was checked.

Original customized menu design: **BLUEFARTS**. Upstream LGL credits and the supplied GPL-3.0 license are retained in `docs/ORIGINAL-CREDITS.md` and `LICENSE`.
