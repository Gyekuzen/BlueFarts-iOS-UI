# Port notes

Your archive is an Android LGL project. The menu uses Java Android widgets and `WindowManager`, despite its IMGUI filename. Its native code uses JNI, Android libraries and game offsets. It is not a portable Dear ImGui renderer that can simply be rebuilt for iOS.

This separate project recreates the interface for **standalone design and testing**, using one HTML/CSS/JavaScript UI in both the Windows browser preview and the Swift/WebKit iPhone shell.

## Original source mapping

Original paths below are relative to `app/src/main/`.

| Original file | New location |
|---|---|
| `java/com/bluefarts/modmenu/Menu.java` | `BlueFartsUI/Web/index.html`, `style.css`, `app.js` |
| `jni/Main.cpp` feature-list functions | `BlueFartsUI/Web/menu-data.js` |
| `jni/Menu/Menu.h` settings and icon | `menu-data.js` and original `bluefarts.png` |
| `java/com/bluefarts/modmenu/Preferences.java` | Local-storage handling in `app.js` |
| `java/com/bluefarts/modmenu/ESPView.java` and `jni/DrawESP/DrawingManager.h` | New sample-target drawing in `app.js` |
| Android app lifecycle | `BlueFartsUI/App.swift` and `Info.plist` |

## Behavior

The five tabs retain 18 player labels, 6 adjustable controls with original ranges, and 23 skin labels. ESP settings include master enable, lines, boxes, skeletons, health, line origin, colors and thickness. The bullet-track preview draws a sample aim line; target/trigger selectors change its marker and label.

The menu supports drag, resize, recenter, minimize to icon and close/reopen. Settings include preferences, icon opacity/size/spin, accent and crosshair. Saved values stay on the current device. Disabling Save preferences removes stored values and keeps the current session's values.

The original cyan (`#00FFFF`), black and dark palette are retained. The window adapts to available space instead of keeping a fixed 900-dp width. The floating icon has a minimum 44-pixel touch target. The original `[FIXED]` gameplay labels were removed because this is a UI preview.

## Limits

This is not an operational game modification. Player/skin switches store preview state. ESP uses three generated sample targets. Android JNI, `.so` libraries, hooks, offsets, login/key services, remote updates and external-link panels are not carried into this standalone preview.

The app's menu stays inside its own window. A menu embedded in an iOS game needs a separate integration with the game's iOS code and renderer. Installing this app does not provide that integration.

The iPhone shell uses bundled files only and has no native game bridge or remote API requests. The original Android archive remains separate. The supplied icon is used inside the UI; a dedicated iOS Home Screen app-icon asset is not included.

## Build

The target is iPhone/iPad on iOS 16+. There are no CocoaPods, Swift Package, Flutter or Java dependencies. The Xcode project and manual cloud workflow produce an unsigned ARM64 IPA for signing afterward. See `VALIDATION.md` for verification limits.

## Credits

Original custom menu: **BLUEFARTS**. Upstream framework: **LGLTeam/Android-Mod-Menu**. The provided GPL-3.0 license and upstream credits are included as `LICENSE` and `ORIGINAL-CREDITS.md`. This UI adaptation uses new implementation code and preserves the supplied feature names, numeric IDs and icon.
