# Windows → iPhone

## Preview and edit

Extract the ZIP. Double-click `preview-windows.cmd`, or open `BlueFartsUI/Web/index.html` directly in Chrome or Edge. Open the extracted project folder in VS Code and edit the files in `BlueFartsUI/Web/`. Save and refresh the browser.

Use your browser's device toolbar for a phone-sized layout. This is a design preview, not an iOS simulator. The native app keeps content inside the iPhone safe area.

## Put the project in your own GitHub repository

The build runs on a GitHub-hosted Mac. Xcode does not need to be installed on your Windows computer.

Using [GitHub Desktop](https://desktop.github.com/):

1. Sign in and choose **File → Add local repository**.
2. Select the extracted `BlueFarts-iOS-UI` folder. If it is not a Git repository, use the offered **create a repository here** option.
3. Commit the source files if necessary, then choose **Publish repository**. Keep **Keep this code private** selected.
4. Check that the repository root contains `BlueFartsUI.xcodeproj`, `BlueFartsUI`, `scripts` and `.github/workflows/build-ios.yml`.

Publish the extracted source files, including `.github`, not just the ZIP. No Apple-account secrets are needed in this repository or workflow. GitHub macOS jobs consume Actions usage; check your account's quota and spending settings before running a build.

## Build the IPA

1. Open your repository on GitHub.
2. Choose **Actions → Build iPhone IPA → Run workflow**.
3. Run it on the branch containing your latest source.
4. After a successful green run, open the run and download **BlueFartsUI-unsigned** under **Artifacts**.
5. Extract the artifact ZIP to obtain **`BlueFartsUI-unsigned.ipa`**.

The workflow uses `macos-15` and its installed Xcode. It compiles the app, checks the ARM64 executable and bundled UI resources, then packages the app under `Payload`. The result is unsigned. Download the artifact within seven days, or run another build later.

After editing the UI, commit and push your changes before rebuilding.

## Sign and install over USB

1. Install the Windows version of [Sideloadly](https://sideloadly.io/) and follow the current Windows dependency instructions on its official site.
2. Connect your iPhone with a data-capable USB cable. Unlock it and accept **Trust This Computer** if prompted.
3. Open Sideloadly, select your iPhone, and add `BlueFartsUI-unsigned.ipa`.
4. Enter your Apple account in Sideloadly, press **Start**, and complete account verification there.
5. If required, enable **Settings → Privacy & Security → Developer Mode**, restart and confirm it.
6. If a developer trust prompt appears, use **Settings → General → VPN & Device Management** to trust your own developer profile.
7. Open **BlueFarts UI**.

With a free Apple account, a signed app normally lasts seven days. Use Sideloadly's refresh option or sign it again. Refer to its current FAQ for device/account limits.

## Troubleshooting

| Problem | Check |
|---|---|
| No workflow in Actions | `.github/workflows/build-ios.yml` must be committed at the repository root on the default branch, with Actions enabled. |
| Job will not start | Check Actions quota, billing and account permissions. |
| Xcode build fails | Copy the first actual compiler error from the failed step. Native compilation has not been verified in this Linux environment. |
| IPA will not open directly | It needs signing and installation through Sideloadly. |
| Phone is not detected | Check the cable, unlock/trust state and current Windows dependencies. |
| Old UI on iPhone | Push your changes, rebuild and install the new IPA. |
| Old values reappear | Use Settings → Reset preview values. |

## With a Mac later

Open `BlueFartsUI.xcodeproj`, select your team under **Signing & Capabilities**, choose your iPhone, and press **Run**. `bash scripts/build-ios.sh` creates an unsigned IPA locally.

## References

- [GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
- [Manual workflow runs](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)
- [GitHub Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions)
- [Sideloadly FAQ](https://sideloadly.io/faq.html)
- [Xcode requirements](https://developer.apple.com/xcode/system-requirements)
