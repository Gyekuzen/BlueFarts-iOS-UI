# Validation

## Passed in this environment

- JavaScript syntax checks for `app.js` and `menu-data.js` using Node.
- Bash syntax check for `scripts/build-ios.sh`.
- Xcode project property-list parsing, object-reference resolution and shared-scheme target references.
- Info.plist XML parsing and scene-delegate configuration checks.
- Workflow YAML and VS Code task JSON parsing.
- HTML local-asset existence and unique-ID checks.
- Five tabs with 71 unique control IDs; expected 18 player switches, 6 adjustable sliders and 23 skin entries.
- Slider default/range and selector-index checks.
- ZIP integrity and required-file checks during packaging.

## Not verified

An interactive browser runtime was unavailable, and the attempted browser download did not produce a usable archive. Touch/mouse interaction, screenshots and visual layout have therefore not been browser-tested here.

This environment is Linux and has no Apple SDK or Xcode. Native iOS compilation, IPA generation, signing, physical-device installation and actual WKWebView behavior have not been tested here. The included cloud workflow must run successfully before an IPA exists.

Open `preview-windows.cmd` for the first interactive check. Then follow `WINDOWS-TO-IPHONE.md` to run the cloud build and install on your phone. If a cloud build fails, copy the first compiler error from the failed step.
