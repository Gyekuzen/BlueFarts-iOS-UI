// Original labels and IDs from the supplied BLUEFARTS project.
window.MENU_DATA = [
  {
    "id": "esp",
    "label": "ESP / BULLET TRACK",
    "short": "ESP / TRACK",
    "help": "Test the styling on sample targets. Hide the menu to inspect the scene.",
    "sections": [
      {
        "label": "ESP MENU",
        "items": [
          {
            "id": "100",
            "label": "ESP",
            "type": "toggle",
            "default": false
          },
          {
            "id": "101",
            "label": "ESP LINE",
            "type": "check",
            "default": false
          },
          {
            "id": "102",
            "label": "ESP BOX",
            "type": "check",
            "default": false
          },
          {
            "id": "103",
            "label": "ESP SKELETON",
            "type": "check",
            "default": false
          },
          {
            "id": "104",
            "label": "ESP HEALTH",
            "type": "check",
            "default": false
          },
          {
            "id": "105",
            "label": "LINES FROM BOTTOM",
            "type": "toggle",
            "default": false
          }
        ]
      },
      {
        "label": "BULLET TRACK",
        "items": [
          {
            "id": "201",
            "label": "BULLET TRACK",
            "type": "toggle",
            "default": false
          },
          {
            "id": "202",
            "label": "TARGET",
            "type": "select",
            "default": 0,
            "options": [
              "Head",
              "Chest",
              "Body"
            ]
          },
          {
            "id": "203",
            "label": "TRIGGER",
            "type": "select",
            "default": 0,
            "options": [
              "Scoping",
              "Hip firing"
            ]
          }
        ]
      },
      {
        "label": "COLOR & THICKNESS",
        "items": [
          {
            "id": "106",
            "label": "ESP LINE COLOR",
            "type": "select",
            "default": 0,
            "options": [
              "Green",
              "Red",
              "Cyan",
              "Yellow",
              "Blue",
              "Purple",
              "Pink",
              "Orange",
              "White",
              "Rainbow"
            ]
          },
          {
            "id": "109",
            "label": "ESP LINE THICKNESS",
            "type": "range",
            "default": 2,
            "min": 1,
            "max": 10
          },
          {
            "id": "107",
            "label": "ESP BOX COLOR",
            "type": "select",
            "default": 0,
            "options": [
              "Green",
              "Red",
              "Cyan",
              "Yellow",
              "Blue",
              "Purple",
              "Pink",
              "Orange",
              "White",
              "Rainbow"
            ]
          },
          {
            "id": "110",
            "label": "ESP BOX THICKNESS",
            "type": "range",
            "default": 2,
            "min": 1,
            "max": 10
          },
          {
            "id": "108",
            "label": "ESP SKELETON COLOR",
            "type": "select",
            "default": 0,
            "options": [
              "Green",
              "Red",
              "Cyan",
              "Yellow",
              "Blue",
              "Purple",
              "Pink",
              "Orange",
              "White",
              "Rainbow"
            ]
          },
          {
            "id": "111",
            "label": "ESP SKELETON THICKNESS",
            "type": "range",
            "default": 2,
            "min": 1,
            "max": 10
          }
        ],
        "collapse": true
      },
      {
        "label": "CROSSHAIR",
        "items": [
          {
            "id": "crosshair",
            "label": "CROSSHAIR",
            "type": "select",
            "default": 0,
            "options": [
              "Off",
              "Cross",
              "Dot",
              "Circle"
            ]
          },
          {
            "id": "crosshair-size",
            "label": "CROSSHAIR SIZE",
            "type": "range",
            "default": 12,
            "min": 6,
            "max": 32
          }
        ],
        "collapse": true
      }
    ]
  },
  {
    "id": "player",
    "label": "PLAYER MENU",
    "short": "PLAYER",
    "help": "These switches store preview values. They are not connected to a game.",
    "sections": [
      {
        "label": "PLAYER FEATURES",
        "items": [
          {
            "id": "1",
            "label": "WALLHACK",
            "type": "toggle",
            "default": false
          },
          {
            "id": "2",
            "label": "EXPANDED HITBOX",
            "type": "toggle",
            "default": false
          },
          {
            "id": "3",
            "label": "FAST SCOPE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "4",
            "label": "FAST SWITCH",
            "type": "toggle",
            "default": false
          },
          {
            "id": "5",
            "label": "FAST SHOT SNIPER",
            "type": "toggle",
            "default": false
          },
          {
            "id": "6",
            "label": "RAPID FIRE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "7",
            "label": "NO RECOIL",
            "type": "toggle",
            "default": false
          },
          {
            "id": "8",
            "label": "NO SPREAD",
            "type": "toggle",
            "default": false
          },
          {
            "id": "9",
            "label": "NO RELOAD",
            "type": "toggle",
            "default": false
          },
          {
            "id": "10",
            "label": "NO SHAKE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "11",
            "label": "NO FLASHBANG",
            "type": "toggle",
            "default": false
          },
          {
            "id": "12",
            "label": "NO PARACHUTE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "13",
            "label": "NO OVERHEAT",
            "type": "toggle",
            "default": false
          },
          {
            "id": "14",
            "label": "BR TAGS",
            "type": "toggle",
            "default": false
          },
          {
            "id": "15",
            "label": "ADVANCE UAV",
            "type": "toggle",
            "default": false
          },
          {
            "id": "16",
            "label": "JUMP BOOST",
            "type": "toggle",
            "default": false
          },
          {
            "id": "17",
            "label": "SKIP TUTORIAL",
            "type": "toggle",
            "default": false
          },
          {
            "id": "18",
            "label": "UNLIMITED AMMO",
            "type": "toggle",
            "default": false
          }
        ]
      }
    ]
  },
  {
    "id": "adjustable",
    "label": "ADJUSTABLE MENU",
    "short": "ADJUSTABLE",
    "help": "Original slider labels and ranges. All values are local to this preview.",
    "sections": [
      {
        "label": "ADJUSTABLE FEATURES",
        "items": [
          {
            "id": "19",
            "label": "AIMBOT ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 150
          },
          {
            "id": "20",
            "label": "SNOWBOARD ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 150
          },
          {
            "id": "21",
            "label": "FAST SWIM ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 10
          },
          {
            "id": "22",
            "label": "SPEEDHACK ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 10
          },
          {
            "id": "23",
            "label": "JUMP HEIGHT ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 80
          },
          {
            "id": "24",
            "label": "FAST DIVE ADJUSTABLE",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 150
          }
        ]
      }
    ]
  },
  {
    "id": "skin",
    "label": "SKIN MENU",
    "short": "SKIN",
    "help": "Search the original skin labels and test the selection switches.",
    "sections": [
      {
        "label": "GUN SKIN MENU",
        "items": [
          {
            "id": "301",
            "label": "DIAMOND CAMO - ALL GUNS",
            "type": "toggle",
            "default": false
          },
          {
            "id": "302",
            "label": "DAMASCUS CAMO - ALL GUNS",
            "type": "toggle",
            "default": false
          },
          {
            "id": "303",
            "label": "AK117 - MEMENTO MORI",
            "type": "toggle",
            "default": false
          },
          {
            "id": "304",
            "label": "AK-47 - RADIANCE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "305",
            "label": "AK117 - LAVA REMIX",
            "type": "toggle",
            "default": false
          },
          {
            "id": "306",
            "label": "VMP - TOXIC BLOOMS",
            "type": "toggle",
            "default": false
          },
          {
            "id": "307",
            "label": "CX9 - LETHAL HOLLOW",
            "type": "toggle",
            "default": false
          },
          {
            "id": "308",
            "label": "TYPE 19 - CELESTIAL INK",
            "type": "toggle",
            "default": false
          },
          {
            "id": "309",
            "label": "QQ9 - DUAL KINETICS",
            "type": "toggle",
            "default": false
          },
          {
            "id": "310",
            "label": "CBR4 - AMOEBA",
            "type": "toggle",
            "default": false
          },
          {
            "id": "311",
            "label": "MG42 - THE CAMPAIGN",
            "type": "toggle",
            "default": false
          },
          {
            "id": "312",
            "label": "FFAR 1 - BRIGHT BLADE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "313",
            "label": "DL Q33 - LOTUS FLAMES",
            "type": "toggle",
            "default": false
          },
          {
            "id": "314",
            "label": "BP50 - ION ERUPTION",
            "type": "toggle",
            "default": false
          },
          {
            "id": "315",
            "label": "EM2 - ECLIPSE PHASER",
            "type": "toggle",
            "default": false
          },
          {
            "id": "316",
            "label": "GRAU 5.56 - PHANTOM'S CORE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "317",
            "label": "AS VAL - DOUBLE EDGE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "318",
            "label": "SWITCHBLADE X9 - NEON LEGEND",
            "type": "toggle",
            "default": false
          },
          {
            "id": "319",
            "label": "JAK-12 - RISING ASHES",
            "type": "toggle",
            "default": false
          },
          {
            "id": "320",
            "label": "FENNEC - ASCENDED",
            "type": "toggle",
            "default": false
          },
          {
            "id": "321",
            "label": "KILO 141 - DEMONSONG",
            "type": "toggle",
            "default": false
          },
          {
            "id": "322",
            "label": "KRIG 6 - ICE DRAKE",
            "type": "toggle",
            "default": false
          },
          {
            "id": "323",
            "label": "ODEN - DIVINE SMITE",
            "type": "toggle",
            "default": false
          }
        ]
      }
    ]
  },
  {
    "id": "settings",
    "label": "SETTINGS MENU",
    "short": "SETTINGS",
    "help": "Tune the menu and floating icon. Preferences can be saved on this device.",
    "sections": [
      {
        "label": "MENU SETTINGS",
        "items": [
          {
            "id": "-1",
            "label": "SAVE PREFERENCES",
            "type": "toggle",
            "default": true
          },
          {
            "id": "-3",
            "label": "AUTO SIZE VERTICALLY",
            "type": "toggle",
            "default": false
          },
          {
            "id": "particles",
            "label": "ANIMATED BACKGROUND",
            "type": "toggle",
            "default": true
          },
          {
            "id": "theme",
            "label": "ACCENT",
            "type": "select",
            "default": 0,
            "options": [
              "Cyan",
              "Ice blue",
              "Rainbow"
            ]
          }
        ]
      },
      {
        "label": "ICON SETTINGS",
        "items": [
          {
            "id": "-8",
            "label": "ICON OPACITY",
            "type": "range",
            "default": 10,
            "min": 2,
            "max": 10
          },
          {
            "id": "-9",
            "label": "ICON SIZE",
            "type": "range",
            "default": 55,
            "min": 32,
            "max": 96
          },
          {
            "id": "-10",
            "label": "ICON SPIN",
            "type": "range",
            "default": 0,
            "min": 0,
            "max": 20
          }
        ]
      }
    ]
  }
];
