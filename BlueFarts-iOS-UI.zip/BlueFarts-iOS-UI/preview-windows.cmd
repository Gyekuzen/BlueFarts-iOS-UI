@echo off
start "" "%~dp0BlueFartsUI\Web\index.html"
