#!/usr/bin/env bash
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
    echo "Use macOS with Xcode, or the included GitHub Actions workflow."
    exit 1
fi
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build_dir="$project_dir/build"
mkdir -p "$build_dir" "$project_dir/dist"
xcodebuild -version
plutil -lint "$project_dir/BlueFartsUI/Info.plist" "$project_dir/BlueFartsUI.xcodeproj/project.pbxproj"
xcodebuild -project "$project_dir/BlueFartsUI.xcodeproj" -scheme BlueFartsUI -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath "$build_dir/DerivedData" CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" clean build
app_dir="$build_dir/DerivedData/Build/Products/Release-iphoneos/BlueFartsUI.app"
test -f "$app_dir/BlueFartsUI"
test -f "$app_dir/Web/index.html"
lipo -verify_arch arm64 "$app_dir/BlueFartsUI"
staging_dir="$(mktemp -d "$build_dir/ipa-staging.XXXXXX")"
trap 'rm -rf "$staging_dir"' EXIT
mkdir -p "$staging_dir/Payload"
ditto "$app_dir" "$staging_dir/Payload/BlueFartsUI.app"
ipa_path="$project_dir/dist/BlueFartsUI-unsigned.ipa"
rm -f "$ipa_path"
ditto -c -k --sequesterRsrc --keepParent "$staging_dir/Payload" "$ipa_path"
echo "Created $ipa_path — sign and install with Sideloadly."
